"""yqapi URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import include, url
from django.contrib import admin
from yqdata import views_topics, views_realtime_monitor, views_dashboard, views_settings, views_senmassage, views_hot_topic, views_search, views_retrieval

urlpatterns = [
    	#url(r'^admin/', include(admin.site.urls)),
    url(r'^yqdata/search$', views_search.Search.as_view()),
    url(r'^yqdata/dashboard$', views_dashboard.dashboard_sourceData),
    url(r'^yqdata/topic_statistics$', views_topics.Topic_statistics.as_view()),
    url(r'^yqdata/topic_analysis$', views_topics.Topic_analysis.as_view()),
    url(r'^yqdata/monitor/all$', views_realtime_monitor.RealtimeMonitorAll.as_view()),
    url(r'^yqdata/monitor/flush$', views_realtime_monitor.RealtimeMonitorFlush.as_view()),
    url(r'^yqdata/monitor/load$', views_realtime_monitor.RealtimeMonitorLoad.as_view()),
    url(r'^yqdata/settopic$', views_settings.SetTopic.as_view()),
    url(r'^yqdata/addtopic$', views_settings.addTopic.as_view()),
    url(r'^yqdata/dataSourceTree$', views_settings.dataSourceTree.as_view()),
    url(r'^yqdata/modifytopic$',views_settings.modifyTopic.as_view()),
    url(r'^yqdata/deletetopic$',views_settings.DeleteTopic.as_view()),
    url(r'^yqdata/senmassage/addui$',views_senmassage.addSenmsg_UI.as_view()),
    url(r'^yqdata/senmassage/showrawmsg$',views_senmassage.showRawMsg.as_view()),
    url(r'^yqdata/senmassage/addmsg$',views_senmassage.addSenmsg_add.as_view()),
    url(r'^yqdata/senmassage/showmsg$',views_senmassage.showSenMsg.as_view()),
    url(r'^yqdata/senmassage/delmesg$',views_senmassage.Mesg_delete.as_view()),
    url(r'^yqdata/senmassage/markmesg$',views_senmassage.Mesg_mark_report.as_view()),
    url(r'^yqdata/senmassage/handlemesg$',views_senmassage.Mesg_mark_handle.as_view()),
    url(r'^yqdata/senmassage/evidence$',views_senmassage.Evidence.as_view()),
    url(r'^yqdata/retrieval$',views_retrieval.Advanced_Retrieval.as_view()),
    url(r'^yqdata/hot_topic$',views_hot_topic.hotTopic.as_view()),
]
