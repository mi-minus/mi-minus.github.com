# -*-coding:utf-8 -*-

#https://github.com/django-json-api/django-rest-framework-json-api/blob/develop/rest_framework_json_api/views.py
#http://django-rest-framework-json-api.readthedocs.io/en/stable/getting-started.html#running-the-example-app
# http://getblimp.github.io/django-rest-framework-jwt/

from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from yqdata.models import Poster, Post, Topic, Site_topic, Site, Datatype_name, Sen_message, User
from datetime import date, timedelta
import datetime
import pandas as pd
from rest_framework.views import APIView
import traceback
import time

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse
import random
from bson.objectid import ObjectId
from mongoengine import *
import json
from mongoengine.queryset.visitor import Q
from serializers import PostSerializer

import logging
logger = logging.getLogger('django')
ISOTIMEFORMAT='%Y-%m-%d %X'
connect('yuqing', alias='default', host='10.31.152.213', port=10005, username='yuqing', password='yuqing123')
datatype_objs = Datatype_name.objects.only("data_type", 'datatype_name')
DTLIST = [(i.data_type, i.datatype_name) for i in datatype_objs]

topic_objs = Topic.objects.only("_id",'topic_name')
TOPICLIST= [(i._id, i.topic_name) for i in topic_objs]

class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, date):
            return obj.strftime('%Y-%m-%d')
        else:
            return json.JSONEncoder.default(self, obj)


#取证api
class Evidence(APIView):
    @csrf_exempt
    def get(self, request, format=None):
        userid = int(request.GET['userId'])
        post_id = request.GET['id']
      
        a = ObjectId(post_id)
        
        try:
            post_msg = Post.objects(_id=a).first()
            
            file_str = post_msg.html.read()

            # file_name = "%s_%s.html" % (post_msg['title'],post_msg['pt_time'])
            file_name = post_id + ".html"
            
            response = HttpResponse(file_str,content_type='application/octet-stream')
            response['Content-Disposition'] = 'attachment;filename=%s' % (file_name)
            return response
        except:
            print traceback.print_exc()



#添加敏感信息，点击界面
class addSenmsg_UI(APIView):
    @csrf_exempt
    def get(self, request, format=None):
        user_id = int(request.GET['userId'])
        post_id = request.GET['id']
        json_out = {}
        a = ObjectId(post_id)
        print a
        print type(a)
        try:
            data = []
            data_msg = {}
            #从post表取出
            post_msg = Post.objects(_id=a).first()
            print '11111'
            # for post_msg in post_msgs:
            print post_msg.url
            print post_msg.title
            print post_msg.html.grid_id
            data_msg['id'] = str(a)
            data_msg['url'] = post_msg.url
            print '333'
            data_msg['title'] = post_msg.title
            data_msg['content'] = post_msg.content
            data_msg['pt_time'] = post_msg.pt_time
            data_msg['dataType'] = post_msg.data_type
            data_msg['board'] = post_msg.board
            data_msg['st_time'] = post_msg.st_time
            data_msg['is_report'] = ''
            data_msg['QQ'] = ''
            data_msg['cellphone'] = ''
            data_msg['Ip'] = ''
            data_msg['poster'] = {}
            data_msg['site_id'] = post_msg.site_id
            data_msg['site_name'] = post_msg.site_name
            data_msg['topic_id'] = post_msg.topic_id
            data_msg['html'] = str(post_msg.html.grid_id)
            data_msg['st_time'] = post_msg.st_time
            data_msg['read_num'] = post_msg.read_num
            data_msg['comm_num'] = post_msg.comm_num
            data_msg['img_url'] = post_msg.img_url
            data_msg['repost_num'] = post_msg.repost_num
            data_msg['lan_type'] = post_msg.lan_type
            data_msg['repost_pt_id'] = post_msg.repost_pt_id
            data_msg['text_type'] = post_msg.text_type
            print post_msg.poster
            if post_msg.poster:
                data_msg['poster']['home_url'] = post_msg.poster.home_url
                data_msg['poster']['img_url'] = post_msg.poster.img_url
                data_msg['poster']['id'] = post_msg.poster.id
                data_msg['poster']['name'] = post_msg.poster.name
            else:
                data_msg['poster']['home_url'] = ""
                data_msg['poster']['img_url'] = ""
                data_msg['poster']['id'] = ""
                data_msg['poster']['name'] = ""
            print '2222'

            data.append(data_msg)

            json_out['success'] = True
            json_out['code'] = 0
            json_out['data'] = data

            return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")
        except:
            print traceback.print_exc()
            json_out['success'] = False
            json_out['code'] = 1
            json_out['data'] = []
            return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")




#添加敏感信息，进行添加
class addSenmsg_add(APIView):
    @csrf_exempt
    def post(self, request, format=None):
        json_out = {}
        json_data=request.data
        #
        try:
            user_id = json_data['userId']
            topic_id = json_data['postData'][0]['topic_id']
            #获得topicname
            topic_name_obj = Topic.objects(_id=topic_id).first()
            topic_name = topic_name_obj.topic_name

            post_id = ObjectId(json_data['postData'][0]['id'])
            url = json_data['postData'][0]['url']
            title = json_data['postData'][0]['title']
            content = json_data['postData'][0]['content']
            pt_time = json_data['postData'][0]['pt_time']
            dataType = json_data['postData'][0]['dataType']
            board = json_data['postData'][0]['board']

            is_report = json_data['postData'][0]['is_report']
            QQ = json_data['postData'][0]['QQ']
            cellphone = json_data['postData'][0]['cellphone']
            Ip = json_data['postData'][0]['Ip']
            poster = Poster(home_url=json_data['postData'][0]['poster']['home_url'],
                            id=json_data['postData'][0]['poster']['id'],
                            img_url=json_data['postData'][0]['poster']['img_url'],
                            name=json_data['postData'][0]['poster']['name'])
            site_id = json_data['postData'][0]['site_id']
            site_name =json_data['postData'][0]['site_name']

            html = json_data['postData'][0]['html'].encode('utf-8')
            st_time = json_data['postData'][0]['st_time']
            read_num = json_data['postData'][0]['read_num']
            comm_num = json_data['postData'][0]['comm_num']
            img_url = json_data['postData'][0]['img_url']
            repost_num = json_data['postData'][0]['repost_num']
            lan_type = json_data['postData'][0]['lan_type']
            repost_pt_id = json_data['postData'][0]['repost_pt_id']
            text_type = json_data['postData'][0]['text_type']
	    sen_words = json_data['postData'][0]['senwords']


            add_msg = Sen_message(
                                _id=post_id,
                                url=url,
                                site_id=site_id,
                                site_name=site_name,
                                topic_id=topic_id,
                                topic_name=topic_name,
                                board=board,
                                data_type=dataType,
                                title=title,
                                content=content,
                                html=html,
                                pt_time=pt_time,
                                st_time=st_time,
                                read_num=read_num,
                                comm_num=comm_num,
                                img_url=img_url,
                                repost_num=repost_num,
                                lan_type=lan_type,
                                repost_pt_id=repost_pt_id,
                                text_type=text_type,
                                poster=poster,
                                phone_num=cellphone,
                                qq_num=QQ,
                                ip_addr=Ip,
				sen_words=sen_words,
                                )
            add_msg.save()

            json_out['code'] = 0
            json_out['success'] = True
            json_out['data'] = '添加成功！'
            return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")
        except:
            print traceback.print_exc()
            json_out['code'] = 1
            json_out['success'] = False
            json_out['data'] = '添加失败！'
            return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")


#列表显示功能
class showSenMsg(APIView):
    @csrf_exempt
    def get(self,request,format=None):
        json_out = {}
        try:
            user_id = int(request.GET['userId'])
            try:
                page_counts = int(request.GET['pageCounts'])  
            except:
                page_counts = request.GET['pageCounts']  
            page_num = int(request.GET['pageNum'])
            is_report = int(request.GET['is_report'])
            topic_id = int(request.GET['topicId'])
            data_type = int(request.GET['dataType'])
            start_date = request.GET['startDate']
            end_date = request.GET['endDate']
            print start_date,end_date
            print len(start_date)
            # print start_date==""

            data = {}

            #先根据条件筛选出符合的信息，再通过pagecounts和pagenum传给前端指定的部分信息

            if start_date == '""' and end_date == '""':
                date_filtered_msg = Sen_message.objects()

                print date_filtered_msg
                print '1111'


            elif start_date != '""' and end_date == '""':
                date_filtered_msg = Sen_message.objects(Q(pt_time__gte=start_date))
            elif start_date == '""' and end_date != '""':
                date_filtered_msg = Sen_message.objects(Q(pt_time__lte=end_date))
            else:
                date_filtered_msg = Sen_message.objects(Q(pt_time__lte=end_date) & Q(pt_time__gte=start_date))
                print '2222'
            print '233333'

            #已经得到根据时间筛选，降序排列
            if is_report != -1:
                if topic_id == -1 and data_type == -1 :
                    all_filtered_msg = date_filtered_msg(is_report=is_report).order_by('-add_time')
                elif topic_id != -1 and data_type == -1:
                    all_filtered_msg = date_filtered_msg(is_report=is_report,topic_id=topic_id).order_by('-add_time')
                elif topic_id == -1 and data_type != -1:
                    all_filtered_msg = date_filtered_msg(is_report=is_report,data_type=data_type).order_by('-add_time')
                else:
                    all_filtered_msg = date_filtered_msg(is_report=is_report,data_type=data_type,topic_id=topic_id).order_by('-add_time')
            else:
                if topic_id == -1 and data_type == -1 :
                    all_filtered_msg = date_filtered_msg().order_by('-add_time')
                elif topic_id != -1 and data_type == -1:
                    all_filtered_msg = date_filtered_msg(topic_id=topic_id).order_by('-add_time')
                elif topic_id == -1 and data_type != -1:
                    all_filtered_msg = date_filtered_msg(data_type=data_type).order_by('-add_time')
                else:
                    all_filtered_msg = date_filtered_msg(data_type=data_type,topic_id=topic_id).order_by('-add_time')


            #已经筛选出全部需要的
            totalCount = len(all_filtered_msg)
            print totalCount
            data['totalCount'] = totalCount
            if page_counts == "all":
                totalPage = 0
                data['totalPage'] = totalPage
                postData = []

                for page_filtered_msg in all_filtered_msg:
                    postData_json = {}
                    postData_json['id'] = str(page_filtered_msg._id)
                    postData_json['url'] = page_filtered_msg.url
                    postData_json['content'] = page_filtered_msg.content
                    postData_json['pt_time'] = page_filtered_msg.pt_time
                    postData_json['data_type'] = page_filtered_msg.data_type
                    postData_json['board'] = page_filtered_msg.board
                    postData_json['add_time'] = page_filtered_msg.add_time
                    postData_json['is_report'] = page_filtered_msg.is_report
                    postData_json['site_id'] = page_filtered_msg.site_id
                    postData_json['site_name'] = page_filtered_msg.site_name
                    postData_json['topic_id'] = page_filtered_msg.topic_id
                    postData_json['html'] = str(page_filtered_msg.html.grid_id)
                    postData_json['st_time'] = page_filtered_msg.st_time
                    postData_json['read_num'] = page_filtered_msg.read_num
                    postData_json['comm_num'] = page_filtered_msg.comm_num
                    postData_json['img_url'] = page_filtered_msg.img_url
                    postData_json['repost_num'] = page_filtered_msg.repost_num
                    postData_json['lan_type'] = page_filtered_msg.lan_type
                    postData_json['repost_pt_id'] = page_filtered_msg.repost_pt_id
                    postData_json['text_type'] = page_filtered_msg.text_type
                    postData_json['poster'] = {}
                    postData_json['ip_addr'] = page_filtered_msg.ip_addr
                    postData_json['qq_num'] = page_filtered_msg.qq_num
                    postData_json['phone_num'] = page_filtered_msg.phone_num
                    postData_json['is_report'] = page_filtered_msg.is_report
                    postData_json['title'] = page_filtered_msg.title
	    	    postData_json['senwords'] = page_filtered_msg.sen_words


                    postData_json['poster']['home_url'] = page_filtered_msg.poster.home_url
                    postData_json['poster']['img_url'] = page_filtered_msg.poster.img_url
                    postData_json['poster']['id'] = page_filtered_msg.poster.id
                    postData_json['poster']['name'] = page_filtered_msg.poster.name


                    postData.append(postData_json)

            else:
                totalPage = totalCount / page_counts + 1
                data['totalPage'] = totalPage

                postData = []
                #计算一页中开始与结束的信息序号
                start_msg_num = (page_num - 1) * page_counts + 1
                print start_msg_num
                end_msg_num = page_num * page_counts

                if end_msg_num > totalCount:
                    end_msg_num = totalCount

                for page_filtered_msg in all_filtered_msg[start_msg_num - 1 : end_msg_num]:
                    postData_json = {}
                    postData_json['id'] = str(page_filtered_msg._id)
                    postData_json['url'] = page_filtered_msg.url
                    postData_json['content'] = page_filtered_msg.content
                    postData_json['pt_time'] = page_filtered_msg.pt_time
                    postData_json['data_type'] = page_filtered_msg.data_type
                    postData_json['board'] = page_filtered_msg.board
                    postData_json['add_time'] = page_filtered_msg.add_time
                    postData_json['is_report'] = page_filtered_msg.is_report
                    postData_json['site_id'] = page_filtered_msg.site_id
                    postData_json['site_name'] = page_filtered_msg.site_name
                    postData_json['topic_id'] = page_filtered_msg.topic_id
                    postData_json['html'] = str(page_filtered_msg.html.grid_id)
                    postData_json['st_time'] = page_filtered_msg.st_time
                    postData_json['read_num'] = page_filtered_msg.read_num
                    postData_json['comm_num'] = page_filtered_msg.comm_num
                    postData_json['img_url'] = page_filtered_msg.img_url
                    postData_json['repost_num'] = page_filtered_msg.repost_num
                    postData_json['lan_type'] = page_filtered_msg.lan_type
                    postData_json['repost_pt_id'] = page_filtered_msg.repost_pt_id
                    postData_json['text_type'] = page_filtered_msg.text_type
                    postData_json['poster'] = {}
                    postData_json['ip_addr'] = page_filtered_msg.ip_addr
                    postData_json['qq_num'] = page_filtered_msg.qq_num
                    postData_json['phone_num'] = page_filtered_msg.phone_num
                    postData_json['is_report'] = page_filtered_msg.is_report
                    postData_json['title'] = page_filtered_msg.title		    
                    postData_json['poster']['home_url'] = page_filtered_msg.poster.home_url
                    postData_json['poster']['img_url'] = page_filtered_msg.poster.img_url
                    postData_json['poster']['id'] = page_filtered_msg.poster.id
                    postData_json['poster']['name'] = page_filtered_msg.poster.name
		    postData_json['senwords'] = page_filtered_msg.sen_words

                    postData.append(postData_json)

            data['postData'] = postData

            json_out['success'] = True
            json_out['code'] = 0
            json_out['data'] = data

            return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")
        except:
            print traceback.print_exc()
            json_out['success'] = False
            json_out['code'] = 1
            json_out['data'] = []
            return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")

#列表元数据信息功能
class showRawMsg(APIView):
    @csrf_exempt
    def get(self,request,format=None):
        user_id = int(request.GET['userId'])
        post_id = request.GET['id']
        json_out = {}
        a = ObjectId(post_id)
        print a
        print type(a)
        try:
            data = []
            data_msg = {}
            #从post表取出
            post_msg = Sen_message.objects(_id=a).first()
            print '11111'
            # for post_msg in post_msgs:
            print post_msg.url
            print post_msg.title
            print post_msg.html.grid_id
            data_msg['id'] = str(a)
            data_msg['url'] = post_msg.url
            print '333'
            data_msg['title'] = post_msg.title
            data_msg['content'] = post_msg.content
            data_msg['pt_time'] = post_msg.pt_time
            data_msg['dataType'] = post_msg.data_type
            data_msg['board'] = post_msg.board
            data_msg['st_time'] = post_msg.st_time
            data_msg['is_report'] = ''
            data_msg['QQ'] = ''
            data_msg['cellphone'] = ''
            data_msg['Ip'] = ''
            data_msg['poster'] = {}
            data_msg['site_id'] = post_msg.site_id
            data_msg['site_name'] = post_msg.site_name
            data_msg['topic_id'] = post_msg.topic_id
            data_msg['html'] = str(post_msg.html.grid_id)
            data_msg['st_time'] = post_msg.st_time
            data_msg['read_num'] = post_msg.read_num
            data_msg['comm_num'] = post_msg.comm_num
            data_msg['img_url'] = post_msg.img_url
            data_msg['repost_num'] = post_msg.repost_num
            data_msg['lan_type'] = post_msg.lan_type
            data_msg['repost_pt_id'] = post_msg.repost_pt_id
            data_msg['text_type'] = post_msg.text_type
	    data_msg['senwords'] = post_msg.sen_words
            data_msg['poster']['home_url'] = post_msg.poster.home_url
            data_msg['poster']['img_url'] = post_msg.poster.img_url
            data_msg['poster']['id'] = post_msg.poster.id
            data_msg['poster']['name'] = post_msg.poster.name

            print '2222'

            data.append(data_msg)

            json_out['success'] = True
            json_out['code'] = 0
            json_out['data'] = data

            return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")
        except:
            print traceback.print_exc()
            json_out['success'] = False
            json_out['code'] = 1
            json_out['data'] = []
            return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")

class Mesg_delete(APIView):
    @csrf_exempt
    def post(self, request, format=None):
        json_data=request.data
        userid=int(json_data['userId'])
        listid=json_data['postLists']
        json_out={}
        data={}
        try:
            for smesgid in listid:
                mesgid=ObjectId(smesgid)
                mesg=Sen_message.objects(Q(_id=mesgid)).first()
                mesg.delete()
            data['message']=u'删除成功！'
            json_out['code']=0
            json_out['success']=True
            json_out['data']=data
        except:
            traceback.print_exc()
            json_out['code']=1
            json_out['success']=False
            data['message']=u'删除失败！'
            json_out['data']={}

        return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")


class Mesg_mark_report(APIView):
    @csrf_exempt
    def post(self, request, format=None):
        json_data=request.data
        userid=int(json_data['userId'])
        listid=json_data['postLists']
        json_out={}
        data={}
        try:
            for smesgid in listid:
                mesgid=ObjectId(smesgid)
                mesg=Sen_message.objects(Q(_id=mesgid)).first()
                mesg.is_report=1
                mesg.save()
            data['message']=u'标记成功！'
            json_out['code']=0
            json_out['success']=True
            json_out['data']=data
        except:
            traceback.print_exc()
            json_out['code']=1
            json_out['success']=False
            json_out['data']={}

        return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")


class Mesg_mark_handle(APIView):
    @csrf_exempt
    def post(self, request, format=None):
        json_data=request.data
        userid=int(json_data['userId'])
        listid=json_data['postLists']
        json_out={}
        data={}
        try:
            for smesgid in listid:
                mesgid=ObjectId(smesgid)
                mesg=Sen_message.objects(Q(_id=mesgid)).first()
                mesg.is_report=2
                mesg.save()
            data['message']=u'标记成功！'
            json_out['code']=0
            json_out['success']=True
            json_out['data']=data
        except:
            traceback.print_exc()
            json_out['code']=1
            json_out['success']=True
            json_out['data']={}

        return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")















