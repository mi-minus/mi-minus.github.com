# -*-coding:utf-8 -*-

#https://github.com/django-json-api/django-rest-framework-json-api/blob/develop/rest_framework_json_api/views.py
#http://django-rest-framework-json-api.readthedocs.io/en/stable/getting-started.html#running-the-example-app
# http://getblimp.github.io/django-rest-framework-jwt/

from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from yqdata.models import Poster, Post, Topic, Site_topic, Site, Datatype_name
from datetime import date, timedelta
import datetime
import pandas as pd
from rest_framework.views import APIView
import traceback

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer

from django.http import HttpResponse
import random

from mongoengine import *
import json
from mongoengine.queryset.visitor import Q
from serializers import PostSerializer

import logging
logger = logging.getLogger('django')

connect('yuqing', alias='default', host='10.31.152.213', port=10005, username='yuqing', password='yuqing123')
datatype_objs = Datatype_name.objects.only("data_type", 'datatype_name')
DTLIST = [(i.data_type, i.datatype_name) for i in datatype_objs]

topic_objs = Topic.objects.only("_id",'topic_name')
TOPICLIST= [(i._id, i.topic_name) for i in topic_objs]

class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, date):
            return obj.strftime('%Y-%m-%d')
        else:
            return json.JSONEncoder.default(self, obj)



#系统设置进入界面
class SetTopic(APIView):  # 127.0.0.1:8000/yqdata/settopic

    @csrf_exempt
    def get(self, request, format=None):
        json_out = {}
        main_out = {}
        user_id = int(request.GET['userId'])     #传入userId


        try:
            #sourcedata
            allsites_list = []
            topicData_list = []


            # allSites部分
            for dataType in range(0,6):
                site_dict = {}
                site_dict['siteTypeId'] = dataType
                datatypename = Datatype_name.objects(Q(data_type=dataType))
                for dataobj in datatypename:
                    site_dict['siteTypeName'] = dataobj.datatype_name
                detailsite_list = []

                smallsite = Site.objects(data_type=dataType)
                for ssite in smallsite:
                    ditailsite_dict = {}
                    ditailsite_dict['siteId'] = ssite._id
                    ditailsite_dict['siteName'] = ssite.site_name
                    detailsite_list.append(ditailsite_dict)
                site_dict['detail_sites'] = detailsite_list
                allsites_list.append(site_dict)


            # topicData部分
            allTopic = Topic.objects(user_id=user_id)
            for alltopic in allTopic:
                topicdata_dict = {}
                topic_id = alltopic._id
                topicdata_dict['topicId'] = topic_id
                topicdata_dict['topicName'] = alltopic.topic_name
                topicdata_dict['topicKeywords'] = alltopic.topic_kws
                sitelists_list = []
                sitesets = Site_topic.objects(topic_id=topic_id)
                for siteset in sitesets:
                    sitelists_dict = {}
                    siteid = siteset.site_id
                    sitelists_dict['siteId'] = siteid
                    nameForSite = Site.objects(_id=siteid)
                    for nameforsite in nameForSite:
                        sitelists_dict['siteName'] = nameforsite.site_name
                    sitelists_list.append(sitelists_dict)
                topicdata_dict['siteLists'] = sitelists_list
                topicData_list.append(topicdata_dict)

            # 外层data部分
            main_out['allSites'] = allsites_list
            main_out['topicData'] = topicData_list


            #最最外层
            json_out['code'] = 0
            json_out['success'] = True
            json_out['data'] = main_out
        except:
            traceback.print_exc()
            json_out['code'] = 1
            json_out['data'] = {}
            json_out['success'] = False


        return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")


#增加话题判断是否重复
class IsRepeat(APIView):
    @csrf_exempt
    def get(self, request, format=None):
        user_id = int(request.POST('userId'))  #传递的参数
        topicname = request.POST('topicName') #传入数据
        json_out = {}

        try:
            topicsets = Topic.objects(Q(user_id=user_id) & Q(topic_name=topicname))
            if topicsets : 
                json_out['code'] = 1
                json_out['success'] = False
                return HttpResponse(json.dumps(json_out,cls=MyEncoder),content_type="application/json")

            json_out['code'] = 0
            json_out['success'] = True
            return HttpResponse(json.dumps(json_out,cls=MyEncoder),content_type="application/json")

        except:
            json_out['code'] = 1
            json_out['success'] = False
            return HttpResponse(json.dumps(json_out,cls=MyEncoder),content_type="application/json")

#增加话题
#使用ParseJson1，粘贴到view.py中
class addTopic(APIView):
    @csrf_exempt
    def post(self, request, format=None):
        json_data = request.data
        json_out = {}

        try:
            user_id = int(json_data['userId'])
            topic_name = json_data['topicName']
            topic_kws = json_data['topicKeywords']
            sites = json_data['sites']

            id_now = Topic.objects(user_id=user_id).order_by('-_id').only('_id').first()
            #加一个userName
            topic_id = id_now._id + 1

            # name_now = Topic.objects(user_name=)


            topic_col = Topic(_id=topic_id, topic_name=topic_name, topic_kws=topic_kws, user_id=user_id, user_name='admin')
            topic_col.save()
            len_list = len(json_data['sites'])
            site_number = 0
            while(site_number < len_list):
                site_id = json_data['sites'][site_number]['siteId']

                topic_site_col = Site_topic(site_id=site_id, topic_id=topic_id, topic_name=topic_name, topic_kws=topic_kws, user_id=user_id, user_name='admin')
                topic_site_col.save()
                site_number += 1

            json_out['code'] = 0
            json_out['success'] = True
            return HttpResponse(json.dumps(json_out,cls=MyEncoder),content_type="application/json")
        except:
            traceback.print_exc()
            json_out['code'] = 1
            json_out['success'] = False
            return HttpResponse(json.dumps(json_out,cls=MyEncoder),content_type="application/json")


#修改话题
#ParseJson2，粘贴到view.py中
class modifyTopic(APIView):
    @csrf_exempt
    def post(self, request, format=None):
        json_data = request.data
        json_out = {}

        try:
            user_id = int(json_data['userId'])
            topic_name = json_data['topicName']
            topic_kws = json_data['topicKeywords']
            sites = json_data['sites']

            topic_obj = Topic.objects(topic_name=topic_name).first()
            topic_id = topic_obj._id

            
            topic_obj.topic_kws = topic_kws
            topic_obj.save()

            site_topic_col = Site_topic.objects(Q(topic_name=topic_name) & Q(user_id=user_id))
            site_topic_col.delete()
            len_list = len(json_data['sites'])
            site_number = 0
            while(site_number < len_list):
                site_id = request.data['sites'][site_number]['siteId']

                topic_site_col = Site_topic(site_id=site_id, topic_id=topic_id, topic_name=topic_name, topic_kws=topic_kws, user_id=user_id, user_name='admin')
                topic_site_col.save()
                site_number += 1

            json_out['code'] = 0
            json_out['success'] = True
            return HttpResponse(json.dumps(json_out,cls=MyEncoder),content_type="application/json")
        except:
            traceback.print_exc()
            json_out['code'] = 1
            json_out['success'] = False
            return HttpResponse(json.dumps(json_out,cls=MyEncoder),content_type="application/json")


#删除话题
class DeleteTopic(APIView):
    @csrf_exempt
    def get(self, request, format=None):
        user_id = int(request.GET['userId']) #传入数据
        topic_id = request.GET['topicId'] #传入数据
        json_out = {}

        try:
            topic_col = Topic.objects(Q(user_id=user_id) & Q(_id=topic_id)).first()
            topic_col.delete()

            site_topic_cols = Site_topic.objects(Q(user_id=user_id) & Q(topic_id=topic_id))
            for site_topic_col in site_topic_cols:
                site_topic_col.delete()

            json_out['code'] = 0
            json_out['success'] = True
            return HttpResponse(json.dumps(json_out,cls=MyEncoder),content_type="application/json")
        except:
            json_out['code'] = 1
            json_out['success'] = False
            return HttpResponse(json.dumps(json_out,cls=MyEncoder),content_type="application/json")

#返回站点树
class dataSourceTree(APIView):
    @csrf_exempt
    def get(self, request, format=None):
        json_out = {}
        main_out = {}

        try:
            #sourcedata
            allsites_list = []
            topicData_list = []


            # allSites部分
            for dataType in range(0,6):
                site_dict = {}
                site_dict['siteTypeId'] = dataType
                datatypename = Datatype_name.objects(Q(data_type=dataType))
                for dataobj in datatypename:
                    site_dict['siteTypeName'] = dataobj.datatype_name
                detailsite_list = []

                smallsite = Site.objects(data_type=dataType)
                for ssite in smallsite:
                    ditailsite_dict = {}
                    ditailsite_dict['siteId'] = ssite._id
                    ditailsite_dict['siteName'] = ssite.site_name
                    detailsite_list.append(ditailsite_dict)
                site_dict['detail_sites'] = detailsite_list
                allsites_list.append(site_dict)



            # 外层data部分
            main_out['allSites'] = allsites_list


            #最最外层
            json_out['code'] = 0
            json_out['success'] = True
            json_out['data'] = main_out
        except:
            traceback.print_exc()
            json_out['code'] = 1
            json_out['data'] = {}
            json_out['success'] = False


        return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")

#小测试用类
class TestView(APIView):
    @csrf_exempt
    def get(self, request, format=None):
        allsites_list = []
        json_out = {}

        user_id = 1
        ts = Topic.objects(user_id=user_id).order_by('-_id').only('_id').first()
        print ts._id

        return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")







