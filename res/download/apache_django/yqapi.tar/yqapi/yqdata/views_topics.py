# -*-coding:utf-8 -*-

#https://github.com/django-json-api/django-rest-framework-json-api/blob/develop/rest_framework_json_api/views.py
#http://django-rest-framework-json-api.readthedocs.io/en/stable/getting-started.html#running-the-example-app
# http://getblimp.github.io/django-rest-framework-jwt/

from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from yqdata.models import Poster, Post, Topic, Site_topic, Site, Datatype_name, Hot_Topic
from datetime import date, timedelta
import datetime
import pandas as pd
from rest_framework.views import APIView
import traceback
import random
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer

from django.http import HttpResponse
import random

from mongoengine import *
import json
from mongoengine.queryset.visitor import Q
from serializers import PostSerializer

import logging
logger = logging.getLogger('django')

connect('yuqing', alias='default', host='10.31.152.213', port=10005, username='yuqing', password='yuqing123')
datatype_objs = Datatype_name.objects.only("data_type", 'datatype_name')
DTLIST = [(i.data_type, i.datatype_name) for i in datatype_objs]

datatype_objs = Datatype_name.objects.only("data_type", 'datatype_name')
DTDICT = {i.data_type: i.datatype_name for i in datatype_objs}

topic_objs = Topic.objects.only("_id",'topic_name')
TOPICLIST= [(i._id, i.topic_name) for i in topic_objs]

datatype_objs = Datatype_name.objects.only("data_type", 'datatype_name')
datatypedict={}
for item in datatype_objs:
    datatypedict[item.data_type]=item.datatype_name

site_objs = Site.objects.only("_id", 'site_name')
sitedict={}
for item in site_objs:
    sitedict[item._id]=item.site_name

class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, date):
            return obj.strftime('%Y-%m-%d')
        else:
            return json.JSONEncoder.default(self, obj)


class Topic_statistics(APIView):   # http://127.0.0.1:8081/yqdata/topic_statistics/ 
    @csrf_exempt
    def get(self, request, format=None):
        userid=int(request.GET['userId'])
        json_out={}
        data=[]
        try:
            res=Topic.objects(Q(user_id=userid))
            for topic in res:
                temp={}
                temp['topicId']=topic._id
                temp['topicName']=topic.topic_name
                temp['topicKeywords']=topic.topic_kws
                temp['imgs']=''
		temp['summary']=topic.summary
                data.append(temp)
            json_out['code']=0
            json_out['success']=True
            json_out['data']=data
        except:
            traceback.print_exc()
            json_out['code']=1
            json_out['success']=False
            json_out['data']={}

        return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")
        
class Topic_analysis(APIView):  # http://127.0.0.1:8081/yqdata/topic_analysis/
    @csrf_exempt
    def get(self, request, format=None):
        userid=int(request.GET['userId'])
        topicid=int(request.GET['topicId'])
        json_out={}
        data={}
        try:
            year_now=date.today().year
            month_now=date.today().month
            day_now=date.today().day
            month_find=0
            year_find=0
            date_find_min=None
            date_find_max=None
            if month_now<3:
                month_find=month_now-2+12
                year_find=year_now-1
            else:
                month_find=month_now-2
                year_find=year_now
            date_find_min=datetime.datetime.combine(date(year_find, month_find, 1), datetime.time.min)
            date_find_max=datetime.datetime.combine(date(year_now, month_now, day_now), datetime.time.max)
            topics=Topic.objects(Q(user_id=userid)&Q(_id=topicid))
            for topic in topics:
                data['topicId']=topic._id
                data['topicName']=topic.topic_name
                data['topic_kws']=topic.topic_kws
                res1=Post.objects(Q(topic_id=topicid)&Q(pt_time__gte=date_find_min)&Q(pt_time__lte=date_find_max)).only('pt_time','site_id','data_type','comm_num')
                click_num=res1.sum('comm_num')
                postdata=[]
                for post in res1:
                    temp={}
                    temp['postTime']=post.pt_time
                    temp['site_id']=post.site_id
                    temp['dataType']=post.data_type
                    temp['site_name']=sitedict[int(post.site_id)]
                    # temp['site_name']=Site.objects(Q(_id=post.site_id)).only('site_name').first().site_name
                    temp['dataTypeName']=datatypedict[int(post.data_type)]
                    postdata.append(temp)
                data['clickNums']=click_num
                data['postData']=postdata
            json_out['code']=0
            json_out['success']=True
            json_out['data']=data
        except:
            traceback.print_exc()
            json_out['code']=1
            json_out['success']=False
            json_out['data']={}

        return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")

# class Topic_analysis(APIView):  # http://127.0.0.1:8081/yqdata/topic_analysis/
#     @csrf_exempt
#     def get(self, request, format=None):
#         userid=int(request.GET['userId'])
#         topicid=int(request.GET['topicId'])
#         json_out={}
#         data={}
#         try:
#             year_now=date.today().year
#             month_now=date.today().month
#             month_find=1
#             day_find=30
#             date_find_min=None
#             date_find_max=None
#             if month_now==12:
#                 day_find=31
#                 date_find_min=datetime.datetime.combine(date(year_now, month_find, 1), datetime.time.min)
#                 date_find_max=datetime.datetime.combine(date(year_now, month_now, day_find), datetime.time.max)
#             else:
#                 month_find=month_now-12+13
#                 if month_now==2:
#                     flag=is_leap_year(year_now)
#                     if flag==1:
#                         day_find=29
#                     else:
#                         day_find=28
#                 else:
#                     if month_now in [1,3,5,7,8,10]:
#                         day_find=31
#                 date_find_min=datetime.datetime.combine(date((year_now-1), month_find, 1), datetime.time.min)
#                 date_find_max=datetime.datetime.combine(date(year_now, month_now, day_find), datetime.time.max)
#             topics=Topic.objects(Q(user_id=userid)&Q(_id=topicid))
#             for topic in topics:
#                 data['topicId']=topic._id
#                 data['topicName']=topic.topic_name
#                 data['topic_kws']=topic.topic_kws
#                 res1=Post.objects(Q(topic_id=topicid)&Q(pt_time__gte=date_find_min)&Q(pt_time__lte=date_find_max)).only('_id','url','pt_time','site_id','data_type','comm_num')
#                 click_num=res1.sum('comm_num')
#                 postdata=[]
#                 for post in res1:
#                     temp={}
#                     temp['id']=str(post._id)
#                     temp['url']=post.url
#                     temp['postTime']=post.pt_time
#                     temp['site_id']=post.site_id
#                     temp['dataType']=post.data_type
#                     temp['site_name']=post.board
#                     temp['dataTypeName']=DTDICT[post.data_type]
#                     postdata.append(temp)
#                 data['clickNums']=click_num
#                 data['postData']=postdata
#             step=0
#             time_analysis=[]
#             date_filter_min=None
#             date_filter_max=None
#             res2=None
#             for index in xrange(1,13):
#                 temp2={}
#                 posttemp=None
#                 if date_find_min.date().year==date_find_max.date().year:
#                     date_filter_min=datetime.datetime.combine(date(date_find_min.date().year, (date_find_min.date().month+step), 1), datetime.time.min)
#                     date_filter_max=datetime.datetime.combine(date(date_find_min.date().year, (date_find_min.date().month+step), 28), datetime.time.max)
#                 else:
#                     if (date_find_min.date().month+step)>12:
#                         date_filter_min=datetime.datetime.combine(date(date_find_max.date().year, (date_find_min.date().month+step-12), 1), datetime.time.min)
#                         date_filter_max=datetime.datetime.combine(date(date_find_max.date().year, (date_find_min.date().month+step-12), 28), datetime.time.max)
#                     else:
#                         date_filter_min=datetime.datetime.combine(date(date_find_min.date().year, (date_find_min.date().month+step), 1), datetime.time.min)
#                         date_filter_max=datetime.datetime.combine(date(date_find_min.date().year, (date_find_min.date().month+step), 28), datetime.time.max)
#                 step=step+1
#                 res2=Post.objects(Q(topic_id=topicid)&Q(pt_time__gte=date_filter_min)&Q(pt_time__lte=date_filter_max)&Q(data_type=4)).count()
#                 if(res2!=0):
#                     posttemp=Post.objects(Q(topic_id=topicid)&Q(pt_time__gte=date_filter_min)&Q(pt_time__lte=date_filter_max)&Q(data_type=4)).only('_id','url','pt_time','site_id','data_type')[random.randint(0, (res2-1))]
#                 if posttemp!=None:
#                     temp2['id']=str(posttemp._id)
#                     temp2['url']=posttemp.url
#                     temp2['postTime']=posttemp.pt_time
#                     temp2['site_id']=posttemp.site_id
#                     temp2['dataType']=posttemp.data_type
#                     temp2['imgUrl']=''
#                     temp2['title'] = posttemp.title
#                     temp2['content'] = posttemp.content
#                     temp2['site_name']=posttemp.board
#                     temp2['dataTypeName']=DTDICT[post.data_type]
#                     time_analysis.append(temp2)
#             data['timeAnaly']=time_analysis
#             json_out['code']=0
#             json_out['success']=True
#             json_out['data']=data
#         except:
#             traceback.print_exc()
#             json_out['code']=1
#             json_out['success']=False
#             json_out['data']={}

#         return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")


def is_leap_year(year):
    if (year%4)==0:
        if (year%100)==0:
            if (year%400)==0:
                return 1
            else:
                return -1
        else:
            return 1
    else:
        return -1

