# -*-coding:utf-8 -*-

#https://github.com/django-json-api/django-rest-framework-json-api/blob/develop/rest_framework_json_api/views.py
#http://django-rest-framework-json-api.readthedocs.io/en/stable/getting-started.html#running-the-example-app
# http://getblimp.github.io/django-rest-framework-jwt/

from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from yqdata.models import Poster, Post, Topic, Site_topic, Site, Datatype_name, Hot_Topic
from datetime import date, timedelta
import datetime
import pandas as pd
from rest_framework.views import APIView
import traceback
import random
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer

from django.http import HttpResponse
import random

from mongoengine import *
import json
from mongoengine.queryset.visitor import Q
from serializers import PostSerializer

import logging
logger = logging.getLogger('django')

connect('yuqing', alias='default', host='10.31.152.213', port=10005, username='yuqing', password='yuqing123')
datatype_objs = Datatype_name.objects.only("data_type", 'datatype_name')
DTLIST = [(i.data_type, i.datatype_name) for i in datatype_objs]

datatype_objs = Datatype_name.objects.only("data_type", 'datatype_name')
DTDICT = {i.data_type: i.datatype_name for i in datatype_objs}

topic_objs = Topic.objects.only("_id",'topic_name')
TOPICLIST= [(i._id, i.topic_name) for i in topic_objs]

class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, date):
            return obj.strftime('%Y-%m-%d')
        else:
            return json.JSONEncoder.default(self, obj)


class hotTopic(APIView):   # http://127.0.0.1:8081/yqdata/hottopic
    @csrf_exempt
    def get(self, request, format=None):
        userid=int(request.GET['userId'])
        json_out={}
        data=[]
        try:
            res=Hot_Topic.objects(Q(user_id=userid))
            for topic in res:
                temp={}
                temp['topicId']=topic._id
                temp['topicName']=topic.topic_name
                temp['topicKeywords']=topic.topic_kws
                temp['imgs']=''
		temp['summary']=topic.summary
                data.append(temp)
            json_out['code']=0
            json_out['success']=True
            json_out['data']=data
        except:
            traceback.print_exc()
            json_out['code']=1
            json_out['success']=False
            json_out['data']={}

        return HttpResponse(json.dumps(json_out, cls=MyEncoder),content_type="application/json")



def is_leap_year(year):
    if (year%4)==0:
        if (year%100)==0:
            if (year%400)==0:
                return 1
            else:
                return -1
        else:
            return 1
    else:
        return -1

